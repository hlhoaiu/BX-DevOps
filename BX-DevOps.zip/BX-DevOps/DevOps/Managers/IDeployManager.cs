﻿namespace DevOps.Managers
{
    public interface IDeployManager
    {
        void Deploy();
    }
}