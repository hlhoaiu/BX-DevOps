﻿namespace DevOps.Managers
{
    public interface IDeployManager
    {
        void DeployAndRelease();
    }
}