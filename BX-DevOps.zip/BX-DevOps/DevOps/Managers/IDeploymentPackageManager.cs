﻿namespace DevOps.Managers
{
    public interface IDeploymentPackageManager
    {
        void Release();
    }
}