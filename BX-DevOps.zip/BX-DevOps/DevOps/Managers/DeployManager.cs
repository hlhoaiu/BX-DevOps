﻿using DevOps.Models.Config;
using DevOps.Services.System;
using DevOps.Services.WinMerge;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevOps.Managers
{
    public class DeployManager : IDeployManager
    {
        private readonly IWinMergeCompareService _winMergeCompareService;
        private readonly IDeployConfigModel _deployConfigModel;
        private readonly ICopyFileService _copyPackageService;
        private readonly IZipService _zipService;

        public DeployManager(
            IWinMergeCompareService winMergeCompareService,
            IDeployConfigModel deployConfigModel,
            ICopyFileService copyPackageService, 
            IZipService zipService)
        {
            _winMergeCompareService = winMergeCompareService;
            _deployConfigModel = deployConfigModel;
            _copyPackageService = copyPackageService;
            _zipService = zipService;
        }

        public void DeployAndRelease()
        {
            var config = _deployConfigModel.GetDeployConfig();
            Directory.CreateDirectory(config.PackageReleasePath);
            var packagePath = Path.Combine(config.PackageBasePath, $"{config.PackageName}.zip");
            var releaseDirectories = new string[] { config.PackageReleasePath };
            _copyPackageService.Copy(packagePath, releaseDirectories);
            var formPath = Path.Combine(config.PackageBasePath, config.DeploymentFormName);
            _copyPackageService.Copy(formPath, releaseDirectories);
            return;
            var sourceZipPath = Path.Combine(config.PackageCompilePath, "Release.zip");
            var unZipToPath = Path.Combine(config.PackageCompilePath, "Release");
            Directory.CreateDirectory(unZipToPath);
            _zipService.UnZip(sourceZipPath, unZipToPath);
            _winMergeCompareService.Compare(unZipToPath, config.ProductionProgramPath);
        }
    }
}
