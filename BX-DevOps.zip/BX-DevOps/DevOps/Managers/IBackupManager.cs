﻿namespace DevOps.Managers
{
    public interface IBackupManager
    {
        void Backup();
    }
}