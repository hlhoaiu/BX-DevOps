﻿namespace DevOps.Managers
{
    public interface IImplFormManager
    {
        void Release();
    }
}