﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevOps.Services.WinMerge
{
    public class WinMergeCompareService : IWinMergeCompareService
    {
        public void Compare()
        {
            throw new NotImplementedException();
        }
    }
}
