﻿namespace DevOps.Services.WinMerge
{
    public interface IWinMergeReportService
    {
        void GenerateReport();
    }
}