﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevOps.Services.WinMerge
{
    public class WinMergeReportService : IWinMergeReportService
    {
        public void GenerateReport()
        {
            // check can we directly generate the report through command
            throw new NotImplementedException();
        }
    }
}
