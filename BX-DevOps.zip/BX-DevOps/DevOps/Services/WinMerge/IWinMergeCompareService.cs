﻿namespace DevOps.Services.WinMerge
{
    public interface IWinMergeCompareService
    {
        void Compare();
    }
}