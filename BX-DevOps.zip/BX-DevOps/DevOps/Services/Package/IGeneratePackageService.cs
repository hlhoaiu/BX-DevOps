﻿namespace DevOps.Services.System
{
    public interface IGeneratePackageService
    {
        void Generate();
    }
}